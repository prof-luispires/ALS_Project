# Channel-Aware Adaptive Hybrid RF/FSO/THz Maritime Wireless Networking

Reproducibility repository prepared for the Springer major revision.

## Canonical methodology

- Four scenarios: `clear`, `rain`, `fog`, `worst`.
- 10 independent atmospheric realizations per scenario.
- 400 distances per realization, 10–4000 m in 10 m increments.
- 16,000 canonical samples.
- Feasible channel: SNR >= 0 dB and capacity >= 100 kbit/s.
- Reference action: minimum transmit energy per bit, `Eb = Ptx/C`, among feasible channels.
- If all channels are infeasible, RF is an explicit fallback and is flagged separately.
- FSO geometry: 1550 nm, 2 mrad beam divergence, 0.20 m receiver aperture.

## Repository structure

- `src/`: channel models, configuration, reference policy, dataset generation and experiment scripts.
- `data/canonical/`: canonical dataset, scenario realizations, metadata and audit.
- `results/supervised/`: matched-condition supervised results.
- `results/cross_scenario/`: scenario-holdout generalization results.
- `results/noise_robustness/`: SNR measurement-noise robustness results.
- `results/dqn/`: PyTorch DQN results and figures.
- `models/dqn/`: trained DQN weights for five seeds and two state modes.
- `manuscript/`: manuscript snapshots used during the revision.
- `docs/`: revision notes and repository manifest.

## Main experiments

### Supervised matched-condition
Evaluation uses complete atmospheric realizations as groups. For each of 10 seeds, two of ten realizations per scenario are held out. Two feature conditions are evaluated: environmental-only and full-information.

### Cross-scenario
Three explicit protocols expose class-coverage limitations, including a single-class Clear-only stress test and a strict `Clear+Rain+Fog -> Worst` unseen-scenario test.

### Noise robustness
Independent zero-mean Gaussian noise is added to held-out SNR observations at sigma = 0, 1, 2, 3 and 5 dB. Capacity and Eb are recomputed from noisy SNR so clean energy features cannot leak information.

### DQN
The DQN is implemented directly in PyTorch. Because dataset rows are independent channel-selection contexts rather than a defensible temporal sequence, the problem is treated as contextual one-step selection with `gamma=0`. The reward is aligned with QoS feasibility and minimum transmit-Eb selection, not maximum SNR.

## Key DQN parameters

- Network: 64-64 ReLU
- Optimizer: Adam
- Learning rate: 1e-3
- Replay buffer: 50,000
- Batch size: 64
- Learning starts: 1,000
- Train frequency: 4
- Training steps: 100,000
- Epsilon: 1.0 -> 0.05 over first 20% of training
- Seeds: 11, 22, 33, 44, 55

## Reproduction

Create an environment and install dependencies:

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Dataset generation:

```bash
cd src
python generate_dataset.py
```

The included `data/canonical/` and `results/` directories preserve the exact revision artifacts used for reporting.

## Important interpretation

The analytical reference reaches agreement 1.0 by construction and is not a learned competitor. The full-information DQN closely reproduces the physical policy, but the revision does **not** claim DQN superiority over supervised learning. Environmental-only supervised Random Forest performs better than environmental-only DQN in the current experiments.
